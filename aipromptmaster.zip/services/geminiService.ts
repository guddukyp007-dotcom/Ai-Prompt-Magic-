import { GoogleGenAI } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateCreativePrompt = async (topic: string): Promise<string> => {
  try {
    const ai = getClient();
    const model = 'gemini-2.5-flash';
    
    const prompt = `You are an expert AI art prompt engineer. Create a detailed, high-quality image generation prompt for the topic: "${topic}". 
    Include details about lighting, camera angle, style (e.g., photorealistic, 3D render, cinematic), and mood. 
    Output ONLY the prompt text, no introduction.`;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });

    return response.text || "Could not generate prompt. Please try again.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error connecting to AI service. Please check your API key.";
  }
};
