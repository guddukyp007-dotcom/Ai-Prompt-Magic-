import React from 'react';

export interface Post {
  id: string;
  title: string;
  author: string;
  date: string;
  category: string;
  imageCollage: string[]; // Array of image URLs for the collage effect
  content: string;
  tags: string[];
}

export interface NavItem {
  label: string;
  icon?: React.ReactNode;
  action?: () => void;
}

export enum ViewState {
  HOME = 'HOME',
  POST_DETAIL = 'POST_DETAIL',
  LEGAL_PRIVACY = 'LEGAL_PRIVACY',
  LEGAL_TERMS = 'LEGAL_TERMS',
  LEGAL_DISCLAIMER = 'LEGAL_DISCLAIMER',
  CONTACT = 'CONTACT',
  GEMINI_TOOL = 'GEMINI_TOOL'
}