import React from 'react';

export const PrivacyPolicy: React.FC = () => (
  <div className="prose max-w-none text-gray-800 animate-[fadeIn_0.5s_ease-out]">
    <h1 className="text-3xl font-bold mb-6 text-gray-900 border-b pb-4">Privacy Policy</h1>
    <p className="text-sm text-gray-500 mb-6">Last updated: October 26, 2025</p>
    
    <p className="mb-4">At <strong>Ai Prompt Editing</strong>, accessible from aipromptediting.in, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Ai Prompt Editing and how we use it.</p>
    
    <p className="mb-4">If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.</p>
    
    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">Log Files</h2>
    <p className="mb-4">Ai Prompt Editing follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services' analytics. The information collected by log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is for analyzing trends, administering the site, tracking users' movement on the website, and gathering demographic information.</p>

    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">Cookies and Web Beacons</h2>
    <p className="mb-4">Like any other website, Ai Prompt Editing uses 'cookies'. These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors' browser type and/or other information.</p>

    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">Google DoubleClick DART Cookie</h2>
    <p className="mb-4">Google is one of a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to www.website.com and other sites on the internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL – <a href="https://policies.google.com/technologies/ads" className="text-blue-600 hover:underline">https://policies.google.com/technologies/ads</a></p>
  
    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">Consent</h2>
    <p className="mb-4">By using our website, you hereby consent to our Privacy Policy and agree to its Terms and Conditions.</p>
  </div>
);

export const TermsOfService: React.FC = () => (
  <div className="prose max-w-none text-gray-800 animate-[fadeIn_0.5s_ease-out]">
    <h1 className="text-3xl font-bold mb-6 text-gray-900 border-b pb-4">Terms and Conditions</h1>
    <p className="text-sm text-gray-500 mb-6">Last updated: October 26, 2025</p>

    <p className="mb-4">Welcome to Ai Prompt Editing!</p>
    <p className="mb-4">These terms and conditions outline the rules and regulations for the use of Ai Prompt Editing's Website, located at aipromptediting.in.</p>
    <p className="mb-4">By accessing this website we assume you accept these terms and conditions. Do not continue to use Ai Prompt Editing if you do not agree to take all of the terms and conditions stated on this page.</p>
    
    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">License</h2>
    <p className="mb-4">Unless otherwise stated, Ai Prompt Editing and/or its licensors own the intellectual property rights for all material on Ai Prompt Editing. All intellectual property rights are reserved. You may access this from Ai Prompt Editing for your own personal use subjected to restrictions set in these terms and conditions.</p>
    
    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">You must not:</h2>
    <ul className="list-disc pl-5 mb-4 space-y-2">
      <li>Republish material from Ai Prompt Editing</li>
      <li>Sell, rent or sub-license material from Ai Prompt Editing</li>
      <li>Reproduce, duplicate or copy material from Ai Prompt Editing</li>
      <li>Redistribute content from Ai Prompt Editing</li>
    </ul>

    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">Content Liability</h2>
    <p className="mb-4">We shall not be hold responsible for any content that appears on your Website. You agree to protect and defend us against all claims that is rising on your Website. No link(s) should appear on any Website that may be interpreted as libelous, obscene or criminal, or which infringes, otherwise violates, or advocates the infringement or other violation of, any third party rights.</p>
  </div>
);

export const Disclaimer: React.FC = () => (
  <div className="prose max-w-none text-gray-800 animate-[fadeIn_0.5s_ease-out]">
    <h1 className="text-3xl font-bold mb-6 text-gray-900 border-b pb-4">Disclaimer</h1>
    
    <p className="mb-4">If you require any more information or have any questions about our site's disclaimer, please feel free to contact us.</p>
    
    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">Disclaimers for Ai Prompt Editing</h2>
    <p className="mb-4">All the information on this website - aipromptediting.in - is published in good faith and for general information purpose only. Ai Prompt Editing does not make any warranties about the completeness, reliability and accuracy of this information. Any action you take upon the information you find on this website (Ai Prompt Editing), is strictly at your own risk. Ai Prompt Editing will not be liable for any losses and/or damages in connection with the use of our website.</p>
    
    <p className="mb-4">From our website, you can visit other websites by following hyperlinks to such external sites. While we strive to provide only quality links to useful and ethical websites, we have no control over the content and nature of these sites. These links to other websites do not imply a recommendation for all the content found on these sites. Site owners and content may change without notice and may occur before we have the opportunity to remove a link which may have gone 'bad'.</p>

    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">AI Generated Content</h2>
    <p className="mb-4">Please note that many prompts and images displayed on this website are generated using Artificial Intelligence (AI). While we strive for quality, results may vary depending on the specific AI tool and version used. We are not affiliated with Google Gemini, Bing Image Creator, or any other AI platforms mentioned.</p>
    
    <h2 className="text-xl font-bold mt-8 mb-4 text-gray-800">Update</h2>
    <p className="mb-4">Should we update, amend or make any changes to this document, those changes will be prominently posted here.</p>
  </div>
);