import React from 'react';
import { Post } from './types';
import { Wand2, Heart, User, Flag, Image, Sparkles, Zap } from 'lucide-react';

export const CATEGORIES = [
  { id: 'Trending', label: 'Trending', icon: <Sparkles size={16} /> },
  { id: 'Girls Prompt', label: 'Girls Prompt', icon: <User size={16} /> },
  { id: 'Couples Prompt', label: 'Couples Prompt', icon: <Heart size={16} /> },
  { id: 'Boys Prompt', label: 'Boys Prompt', icon: <User size={16} /> },
  { id: 'Republic Day Ai', label: 'Republic Day Ai', icon: <Flag size={16} /> },
  { id: 'Gemini Prompts', label: 'Gemini Prompts', icon: <Zap size={16} /> },
  { id: 'Photo Editing', label: 'Photo Editing', icon: <Image size={16} /> },
];

export const MOCK_POSTS: Post[] = [
  {
    id: '1',
    title: 'The Viral Bike Pose Couple Trend: Mastering Google Gemini AI Photo Editing',
    author: 'Admin',
    date: 'Oct 24, 2025',
    category: 'Couples Prompt',
    imageCollage: [
      'https://picsum.photos/400/400?random=1',
      'https://picsum.photos/400/400?random=2',
      'https://picsum.photos/400/400?random=3',
    ],
    tags: ['Couple', 'Bike', 'Trending', 'Viral'],
    content: `Create stunning bike pose couple photos with this new viral prompt. 
    
    **Prompt:** "A young Indian couple sitting on a Royal Enfield Bullet bike on a highway road during sunset. The boy is wearing a denim jacket and jeans, and the girl is wearing a traditional red kurti. Cinematic lighting, 8k resolution, photorealistic style."
    
    **How to use:**
    1. Copy the prompt above.
    2. Open Bing Image Creator or Google Gemini.
    3. Paste and generate!`
  },
  {
    id: '2',
    title: 'Top 5 Boys Stylish Google Gemini AI Photo Editing Prompts: Transform Your Photos',
    author: 'Admin',
    date: 'Oct 23, 2025',
    category: 'Boys Prompt',
    imageCollage: [
      'https://picsum.photos/400/500?random=4',
      'https://picsum.photos/400/300?random=5',
      'https://picsum.photos/400/400?random=6',
    ],
    tags: ['Boys', 'Stylish', 'Attitude', 'Instagram'],
    content: `Elevate your Instagram game with these stylish prompts for boys.
    
    **Prompt 1:** "A stylish young man standing on a neon-lit street in Tokyo at night, wearing a futuristic streetwear outfit with a hoodie and mask. Cyberpunk aesthetic, high contrast."
    
    **Prompt 2:** "Close up portrait of a handsome boy in a suit, golden hour lighting, bokeh background of a city park."`
  },
  {
    id: '3',
    title: 'Vote for BJP Ai Photo Editing with Gemini Ai stunning photos editing prompt',
    author: 'Admin',
    date: 'Oct 22, 2025',
    category: 'Trending',
    imageCollage: [
      'https://picsum.photos/400/400?random=7',
      'https://picsum.photos/400/400?random=8',
      'https://picsum.photos/400/400?random=9',
      'https://picsum.photos/400/400?random=10',
    ],
    tags: ['Election', 'Political', 'Banner'],
    content: `Support your favorite party with these high quality AI generated banners.
    
    **Prompt:** "A realistic 3D illustration of a young man standing on a stage with a political party flag, crowd cheering in background, bright daylight, ultra detailed."`
  },
  {
    id: '4',
    title: 'How to Create Stunning Birthday Photo Edits with Google Gemini in 2025',
    author: 'Admin',
    date: 'Oct 21, 2025',
    category: 'Photo Editing',
    imageCollage: [
      'https://picsum.photos/400/400?random=11',
      'https://picsum.photos/400/400?random=12',
    ],
    tags: ['Birthday', 'Celebration', 'Cake'],
    content: `Make birthdays special with AI.
    
    **Prompt:** "A beautiful birthday celebration setup with purple balloons and a large cake saying 'Happy Birthday', a girl in a princess dress standing next to it, soft lighting, 3d render style."`
  },
  {
    id: '5',
    title: 'Best Gemini Prompts for Realistic Portraits 2025',
    author: 'Admin',
    date: 'Oct 20, 2025',
    category: 'Gemini Prompts',
    imageCollage: [
      'https://picsum.photos/400/400?random=13',
      'https://picsum.photos/400/400?random=14',
    ],
    tags: ['Gemini', 'Portraits', 'Realism'],
    content: `Master the art of realistic portraits with Google Gemini.

    **Prompt:** "A hyper-realistic close-up portrait of an elderly woman with laughing lines, wearing a traditional saree, natural sunlight hitting her face, intricate skin texture, depth of field, 85mm lens style."`
  },
  {
    id: '6',
    title: 'Republic Day 2025: Creative AI Prompts for Social Media',
    author: 'Admin',
    date: 'Oct 19, 2025',
    category: 'Republic Day Ai',
    imageCollage: [
      'https://picsum.photos/400/400?random=15',
      'https://picsum.photos/400/400?random=16',
      'https://picsum.photos/400/400?random=17',
    ],
    tags: ['Republic Day', 'India', 'Patriotic'],
    content: `Celebrate Republic Day with these creative AI prompts.
    
    **Prompt:** "A 3D illustration of a young boy holding the Indian flag, running in a field of green wheat, blue sky, vibrant colors, patriotic theme."`
  },
  {
    id: '7',
    title: 'Cute Girls Photography Prompts for Gemini AI',
    author: 'Admin',
    date: 'Oct 18, 2025',
    category: 'Girls Prompt',
    imageCollage: [
      'https://picsum.photos/400/400?random=18',
      'https://picsum.photos/400/400?random=19',
    ],
    tags: ['Girls', 'Fashion', 'Photography'],
    content: `Create stunning fashion portraits for girls.
    
    **Prompt:** "A fashionable girl wearing a floral summer dress, standing in a sunflower field, holding a straw hat, soft golden hour lighting, dreamy atmosphere."`
  },
  // Added more mock posts to demonstrate load more
  {
    id: '8',
    title: 'Urban Street Style Boys Photography Ideas 2025',
    author: 'Admin',
    date: 'Oct 17, 2025',
    category: 'Boys Prompt',
    imageCollage: [
      'https://picsum.photos/400/400?random=20',
      'https://picsum.photos/400/400?random=21',
    ],
    tags: ['Street Style', 'Urban', 'Fashion'],
    content: `Capture the urban vibe with these prompts.
    
    **Prompt:** "A young man leaning against a graffiti wall in Brooklyn, wearing a leather jacket and sunglasses, holding a skateboard, gritty urban texture, 4k."`
  },
  {
    id: '9',
    title: 'Magical Forest Fantasy Couple Editing',
    author: 'Admin',
    date: 'Oct 16, 2025',
    category: 'Couples Prompt',
    imageCollage: [
      'https://picsum.photos/400/400?random=22',
      'https://picsum.photos/400/400?random=23',
    ],
    tags: ['Fantasy', 'Love', 'Magic'],
    content: `Transport your couple photos to a magical realm.
    
    **Prompt:** "A couple dancing in a bioluminescent forest at night, surrounded by glowing fireflies, wearing elegant ballgowns and suits, magical atmosphere."`
  },
  {
    id: '10',
    title: 'Advanced Gemini Prompt Engineering Techniques',
    author: 'Admin',
    date: 'Oct 15, 2025',
    category: 'Gemini Prompts',
    imageCollage: [
      'https://picsum.photos/400/400?random=24',
      'https://picsum.photos/400/400?random=25',
    ],
    tags: ['Technical', 'Learning', 'Guide'],
    content: `Learn how to control lighting and composition in Gemini.
    
    **Technique:** Use keywords like 'volumetric lighting', 'rule of thirds', and 'color grading' to improve your results.`
  },
  {
    id: '11',
    title: 'Cinematic Car Photoshoot Prompts',
    author: 'Admin',
    date: 'Oct 14, 2025',
    category: 'Photo Editing',
    imageCollage: [
      'https://picsum.photos/400/400?random=26',
      'https://picsum.photos/400/400?random=27',
    ],
    tags: ['Cars', 'Cinematic', 'Action'],
    content: `Get that movie poster look for your car photos.
    
    **Prompt:** "A black sports car drifting on a wet race track at night, neon lights reflecting on the pavement, smoke from tires, motion blur, high octane energy."`
  },
  {
    id: '12',
    title: 'Traditional Indian Wedding Couple AI Art',
    author: 'Admin',
    date: 'Oct 13, 2025',
    category: 'Trending',
    imageCollage: [
      'https://picsum.photos/400/400?random=28',
      'https://picsum.photos/400/400?random=29',
    ],
    tags: ['Wedding', 'Traditional', 'India'],
    content: `Celebrate love and tradition.
    
    **Prompt:** "A royal Indian wedding couple standing in front of the Taj Mahal, wearing intricate gold and red sherwani and lehenga, marigold flower rain, soft romantic lighting."`
  }
];