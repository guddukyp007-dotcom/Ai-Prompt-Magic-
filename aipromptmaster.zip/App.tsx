import React, { useState, useEffect } from 'react';
import { Menu, X, Search, ChevronDown, User, Facebook, Twitter, Instagram, Linkedin, ArrowRight, Wand2, Mail, MapPin, Phone, Copy, Send } from 'lucide-react';
import { Post, ViewState } from './types';
import { CATEGORIES, MOCK_POSTS } from './constants';
import { PrivacyPolicy, TermsOfService, Disclaimer } from './components/LegalContent';
import { generateCreativePrompt } from './services/geminiService';

const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" className="mr-2">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
  </svg>
);

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);
  const [selectedCategory, setSelectedCategory] = useState<string>('Trending');
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [geminiInput, setGeminiInput] = useState('');
  const [geminiOutput, setGeminiOutput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [visibleCount, setVisibleCount] = useState(6);

  // Scroll to top on view change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView, selectedPost, selectedCategory]);

  // Reset visible count when category changes
  useEffect(() => {
    setVisibleCount(6);
  }, [selectedCategory]);

  const handlePostClick = (post: Post) => {
    setSelectedPost(post);
    setCurrentView(ViewState.POST_DETAIL);
  };

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentView(ViewState.HOME);
  };

  const handleGenerate = async () => {
    if (!geminiInput.trim()) return;
    setIsGenerating(true);
    setGeminiOutput('');
    const result = await generateCreativePrompt(geminiInput);
    setGeminiOutput(result);
    setIsGenerating(false);
  };

  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 6);
  };

  const getFilteredPosts = () => {
    if (selectedCategory === 'Trending') return MOCK_POSTS;
    return MOCK_POSTS.filter(post => post.category === selectedCategory);
  };

  const renderContent = () => {
    switch (currentView) {
      case ViewState.POST_DETAIL:
        return selectedPost ? (
          <article className="max-w-4xl mx-auto bg-white min-h-screen p-4 md:p-8 shadow-sm rounded-none md:rounded-lg mt-4 animate-[fadeIn_0.3s_ease-out]">
             <button 
              onClick={() => setCurrentView(ViewState.HOME)}
              className="mb-6 flex items-center text-blue-600 hover:text-blue-800 font-medium transition"
            >
              ← Back to {selectedCategory}
            </button>
            <h1 className="text-2xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">
              {selectedPost.title}
            </h1>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-gray-500 mb-6 border-b pb-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mr-2 text-gray-600">
                  <User size={16} />
                </div>
                <span className="font-semibold text-gray-700">{selectedPost.author}</span>
              </div>
              <span className="hidden md:inline">•</span>
              <span>{selectedPost.date}</span>
              <span className="hidden md:inline">•</span>
              <span className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">{selectedPost.category}</span>
            </div>
            
            {/* Share Buttons */}
            <div className="flex items-center gap-3 mb-8">
              <button 
                  onClick={() => {
                      // In a real app, this would be the actual post URL
                      const url = `${window.location.origin}/post/${selectedPost.id}`;
                      navigator.clipboard.writeText(url);
                      alert('Link copied to clipboard!');
                  }}
                  className="flex-1 bg-black text-white py-2.5 rounded-lg flex items-center justify-center hover:opacity-80 transition shadow-sm"
                  aria-label="Copy Link"
              >
                  <Copy size={20} />
              </button>
              
              <button 
                  onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank')}
                  className="flex-1 bg-[#3b5998] text-white py-2.5 rounded-lg flex items-center justify-center hover:opacity-90 transition shadow-sm"
                  aria-label="Share on Facebook"
              >
                  <Facebook size={20} fill="currentColor" />
              </button>

              <button 
                  onClick={() => {
                    const text = `${selectedPost.title} - Check this out: ${window.location.href}`;
                    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                  }}
                  className="flex-1 bg-[#25D366] text-white py-2.5 rounded-lg flex items-center justify-center hover:opacity-90 transition shadow-sm"
                  aria-label="Share on WhatsApp"
              >
                   <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
              </button>

              <button 
                  onClick={() => {
                    const text = `${selectedPost.title} ${window.location.href}`;
                    window.open(`https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(selectedPost.title)}`, '_blank');
                  }}
                  className="flex-1 bg-[#0088cc] text-white py-2.5 rounded-lg flex items-center justify-center hover:opacity-90 transition shadow-sm"
                  aria-label="Share on Telegram"
              >
                  <Send size={20} className="-ml-1" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-8 rounded-xl overflow-hidden shadow-sm">
               {selectedPost.imageCollage.map((img, idx) => (
                 <img 
                  key={idx} 
                  src={img} 
                  alt={`Detail ${idx}`} 
                  className={`w-full h-48 md:h-80 object-cover hover:scale-105 transition duration-700 ${selectedPost.imageCollage.length === 3 && idx === 0 ? 'col-span-2' : ''}`}
                />
               ))}
            </div>

            <div className="prose prose-lg max-w-none text-gray-700 whitespace-pre-line leading-relaxed">
              {selectedPost.content}
            </div>

            <div className="mt-12 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100 flex flex-col md:flex-row items-center justify-between gap-4">
               <div>
                 <h3 className="text-lg font-bold text-gray-900 mb-1">Want to create your own?</h3>
                 <p className="text-gray-600">Use our integrated Gemini AI tool to generate unique prompts instantly.</p>
               </div>
               <button 
                onClick={() => setCurrentView(ViewState.GEMINI_TOOL)}
                className="bg-blue-600 text-white px-6 py-3 rounded-full font-bold hover:bg-blue-700 transition shadow-lg flex items-center gap-2 whitespace-nowrap"
               >
                 <Wand2 size={18}/> Try AI Generator
               </button>
            </div>
          </article>
        ) : null;

      case ViewState.LEGAL_PRIVACY:
        return <div className="max-w-4xl mx-auto bg-white p-6 md:p-12 my-8 rounded-lg shadow-sm min-h-[60vh]"><PrivacyPolicy /></div>;
      case ViewState.LEGAL_TERMS:
        return <div className="max-w-4xl mx-auto bg-white p-6 md:p-12 my-8 rounded-lg shadow-sm min-h-[60vh]"><TermsOfService /></div>;
      case ViewState.LEGAL_DISCLAIMER:
        return <div className="max-w-4xl mx-auto bg-white p-6 md:p-12 my-8 rounded-lg shadow-sm min-h-[60vh]"><Disclaimer /></div>;
      
      case ViewState.CONTACT:
        return (
          <div className="max-w-4xl mx-auto bg-white p-6 md:p-12 my-8 rounded-lg shadow-sm min-h-[60vh] animate-[fadeIn_0.5s_ease-out]">
            <h1 className="text-3xl font-bold mb-8 text-gray-900 border-b pb-4">Contact Us</h1>
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Have questions about our prompts, legal policies, or just want to say hello? 
                  We'd love to hear from you. Fill out the form or reach us via email.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-gray-700">
                    <Mail className="text-red-600"/> <span>support@aipromptediting.in</span>
                  </div>
                  <div className="flex items-center gap-3 text-gray-700">
                    <MapPin className="text-red-600"/> <span>New Delhi, India</span>
                  </div>
                  <div className="flex items-center gap-3 text-gray-700">
                    <Phone className="text-red-600"/> <span>+91 98765 43210</span>
                  </div>
                </div>
              </div>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                  <input type="text" className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-red-500 outline-none" placeholder="Your Name" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input type="email" className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-red-500 outline-none" placeholder="your@email.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                  <textarea className="w-full border border-gray-300 rounded-lg p-3 h-32 focus:ring-2 focus:ring-red-500 outline-none" placeholder="How can we help?"></textarea>
                </div>
                <button type="button" className="bg-red-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-red-700 transition w-full">Send Message</button>
              </form>
            </div>
          </div>
        );

      case ViewState.GEMINI_TOOL:
        return (
          <div className="max-w-3xl mx-auto p-4 md:p-8 min-h-[80vh]">
            <div className="bg-gradient-to-br from-indigo-900 to-purple-800 rounded-2xl p-6 md:p-10 text-white shadow-2xl mb-8">
              <h1 className="text-3xl md:text-4xl font-bold mb-4 flex items-center gap-3">
                <Wand2 className="animate-pulse text-yellow-400"/> 
                <span>AI Prompt Generator</span>
              </h1>
              <p className="text-indigo-100 mb-8 text-lg">
                Powered by Google Gemini. Enter a simple concept, and get a professional, highly detailed image generation prompt instantly.
              </p>
              
              <div className="bg-white/10 p-2 rounded-xl backdrop-blur-md border border-white/20 flex flex-col md:flex-row gap-2 shadow-inner">
                <input 
                  type="text" 
                  value={geminiInput}
                  onChange={(e) => setGeminiInput(e.target.value)}
                  placeholder="E.g., Cyberpunk cat in rain..."
                  className="flex-1 bg-transparent border-none outline-none text-white placeholder-indigo-300 px-4 py-3 text-lg"
                  onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                />
                <button 
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="bg-white text-indigo-900 font-bold px-8 py-3 rounded-lg hover:bg-indigo-50 transition disabled:opacity-50 flex items-center justify-center min-w-[140px] shadow-lg"
                >
                  {isGenerating ? (
                    <span className="flex items-center gap-2">
                      <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-900"></span>
                      Working...
                    </span>
                  ) : 'Generate'}
                </button>
              </div>
            </div>

            {geminiOutput && (
              <div className="bg-white rounded-xl p-6 md:p-8 shadow-xl border border-gray-100 animate-[fadeIn_0.5s_ease-out]">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold text-gray-800">Generated Prompt Result</h3>
                  <span className="text-xs font-medium bg-green-100 text-green-700 px-2 py-1 rounded">Ready to copy</span>
                </div>
                <div className="bg-gray-50 p-5 rounded-xl border border-gray-200 text-gray-700 font-mono text-sm leading-relaxed relative group">
                  {geminiOutput}
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(geminiOutput);
                      alert('Prompt copied to clipboard!');
                    }}
                    className="absolute top-2 right-2 bg-white shadow-md text-xs font-bold px-3 py-1.5 rounded border border-gray-200 hover:bg-blue-50 hover:text-blue-600 opacity-0 group-hover:opacity-100 transition-all"
                  >
                    Copy Text
                  </button>
                </div>
              </div>
            )}

            <button 
              onClick={() => setCurrentView(ViewState.HOME)}
              className="mt-8 text-gray-500 hover:text-gray-900 flex items-center gap-2 mx-auto font-medium transition"
            >
              ← Return to Home
            </button>
          </div>
        );

      case ViewState.HOME:
      default:
        const allPosts = getFilteredPosts();
        const posts = allPosts.slice(0, visibleCount);
        
        return (
          <>
            {/* Tag Cloud / Discover More */}
            <div className="max-w-7xl mx-auto px-4 py-6">
              <div className="flex flex-wrap gap-3 items-center">
                <div className="bg-gray-200 px-4 py-1.5 rounded-md text-sm font-bold text-gray-700 shadow-sm">Trending Now:</div>
                {['Birthday Edits', 'Couples', 'Gemini AI', 'Prompt Engineering', 'Election 2025'].map((tag) => (
                   <button 
                    key={tag} 
                    className="flex items-center space-x-1 bg-white border border-blue-100 px-4 py-1.5 rounded-full text-blue-600 text-sm font-medium hover:bg-blue-50 transition shadow-sm hover:shadow"
                   >
                     <span className="text-yellow-500">⚡</span>
                     <span>{tag}</span>
                   </button>
                ))}
              </div>
            </div>

            {/* WhatsApp CTA Banner */}
            <div className="max-w-7xl mx-auto px-4 mb-8">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex flex-col md:flex-row items-center justify-between gap-4 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
                <div className="text-center md:text-left z-10">
                   <h3 className="text-xl md:text-2xl font-bold text-gray-800 mb-1">
                     हमारे सभी Trending Updates के लिए जुड़ें!
                   </h3>
                   <p className="text-gray-500 text-sm">Get the latest AI prompts and editing tips directly on your phone.</p>
                </div>
                <button className="bg-[#25D366] hover:bg-[#128C7E] text-white px-8 py-3 rounded-full font-bold shadow-lg shadow-green-200 hover:shadow-green-300 transition-all transform hover:-translate-y-1 flex items-center text-lg z-10 relative group">
                  <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 rounded-full transition"></div>
                  <WhatsAppIcon />
                  चैनल जॉइन करें
                </button>
                {/* Decorative blobs */}
                <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-green-50 rounded-full blur-2xl opacity-50"></div>
                <div className="absolute -left-10 -top-10 w-32 h-32 bg-blue-50 rounded-full blur-2xl opacity-50"></div>
              </div>
            </div>

            {/* Main Feed */}
            <main className="max-w-7xl mx-auto px-4 pb-12">
              {posts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {posts.map((post) => (
                    <div 
                      key={post.id} 
                      onClick={() => handlePostClick(post)}
                      className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-300 cursor-pointer border border-transparent hover:border-gray-100 group flex flex-col h-full"
                    >
                      {/* Image Grid */}
                      <div className="aspect-[4/3] grid grid-cols-2 gap-0.5 bg-gray-100 relative overflow-hidden">
                        {post.imageCollage.slice(0, 3).map((img, idx) => (
                          <div key={idx} className={`overflow-hidden relative ${post.imageCollage.length === 3 && idx === 0 ? 'row-span-2 h-full' : 'h-full'}`}>
                              <img src={img} alt="" className="w-full h-full object-cover group-hover:scale-110 transition duration-700" />
                          </div>
                        ))}
                        {/* Overlay Badge */}
                        <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md text-xs font-bold px-3 py-1.5 rounded-full text-white shadow-sm border border-white/20">
                          {post.category}
                        </div>
                      </div>
                      
                      {/* Content */}
                      <div className="p-5 relative flex-1 flex flex-col">
                        {/* Floating Title Box style */}
                        <div className="bg-white rounded-xl shadow-lg -mt-12 relative z-10 p-4 border border-gray-100 mb-2 flex-1 flex flex-col justify-center">
                          <h2 className="text-lg font-bold text-gray-800 leading-snug line-clamp-2 mb-3 group-hover:text-red-600 transition-colors">
                            {post.title}
                          </h2>
                          <div className="flex items-center text-xs text-gray-500 space-x-2 mt-auto">
                            <img src={`https://ui-avatars.com/api/?name=${post.author}&background=random`} alt={post.author} className="w-6 h-6 rounded-full border border-white shadow-sm" />
                            <span className="font-medium">{post.author}</span>
                            <span>•</span>
                            <span>Read more</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-20 bg-white rounded-xl shadow-sm">
                  <div className="text-gray-300 mb-4"><Search size={48} className="mx-auto"/></div>
                  <h3 className="text-xl font-bold text-gray-800">No posts found</h3>
                  <p className="text-gray-500">Try selecting a different category.</p>
                  <button onClick={() => handleCategoryClick('Trending')} className="mt-4 text-blue-600 font-medium hover:underline">View All</button>
                </div>
              )}
            </main>

            {/* Pagination / Load More */}
            {posts.length < allPosts.length && (
              <div className="flex justify-center pb-12">
                <button 
                  onClick={handleLoadMore}
                  className="bg-[#D32F2F] text-white font-bold py-3 px-10 rounded-full hover:bg-red-700 transition shadow-lg hover:shadow-red-200 transform hover:-translate-y-1 active:translate-y-0 flex items-center gap-2"
                >
                  Load More Posts
                </button>
              </div>
            )}
            
            {/* Show message if all posts are loaded and there were posts to begin with */}
            {posts.length > 0 && posts.length === allPosts.length && allPosts.length > 6 && (
              <div className="text-center pb-12 text-gray-500 text-sm">
                You've reached the end of the list.
              </div>
            )}
          </>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f3f4f6] font-['Poppins']">
      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" onClick={() => setIsSidebarOpen(false)}></div>
          <div className="relative bg-white w-[300px] h-full shadow-2xl flex flex-col animate-[slideRight_0.3s_ease-out]">
            <div className="p-5 border-b flex justify-between items-center bg-gray-50">
               <span className="font-bold text-xl text-gray-900">Menu</span>
               <button onClick={() => setIsSidebarOpen(false)} className="p-2 hover:bg-red-100 hover:text-red-600 rounded-full transition"><X size={24}/></button>
            </div>
            <nav className="p-5 flex-1 overflow-y-auto">
               <ul className="space-y-4">
                 <li onClick={() => { setCurrentView(ViewState.HOME); setIsSidebarOpen(false); }} className="cursor-pointer font-medium text-gray-700 hover:text-red-600 hover:bg-red-50 p-2 rounded transition">Home</li>
                 <li className="cursor-pointer font-medium text-gray-700 flex justify-between items-center group hover:bg-gray-50 p-2 rounded">
                   <span>Prompt Categories</span>
                   <ChevronDown size={16} className="text-gray-400 group-hover:text-red-600"/>
                 </li>
                 <li onClick={() => { setCurrentView(ViewState.GEMINI_TOOL); setIsSidebarOpen(false); }} className="cursor-pointer font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-3 bg-indigo-50 p-3 rounded-lg border border-indigo-100">
                   <Wand2 size={20}/> Gemini Generator
                 </li>
                 <div className="border-t pt-4 mt-4">
                   <li onClick={() => { setCurrentView(ViewState.CONTACT); setIsSidebarOpen(false); }} className="cursor-pointer font-medium text-gray-600 hover:text-gray-900 p-2">Contact Us</li>
                   <li onClick={() => { setCurrentView(ViewState.LEGAL_PRIVACY); setIsSidebarOpen(false); }} className="cursor-pointer font-medium text-gray-600 hover:text-gray-900 p-2">Privacy Policy</li>
                   <li onClick={() => { setCurrentView(ViewState.LEGAL_TERMS); setIsSidebarOpen(false); }} className="cursor-pointer font-medium text-gray-600 hover:text-gray-900 p-2">Terms & Conditions</li>
                 </div>
               </ul>
            </nav>
            <div className="p-4 border-t bg-gray-50 text-xs text-gray-400 text-center">
              Version 2.0.0 • Made with ❤️
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 z-40 bg-gradient-to-r from-[#8B0000] via-[#D32F2F] to-black shadow-lg">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-4">
             <button onClick={() => setIsSidebarOpen(true)} className="text-white p-2 hover:bg-white/20 rounded-lg transition">
               <Menu size={26} />
             </button>
             <div 
              onClick={() => { setCurrentView(ViewState.HOME); setSelectedCategory('Trending'); }}
              className="flex items-center cursor-pointer group"
             >
               <div className="w-10 h-10 rounded-full border-2 border-yellow-400 flex items-center justify-center bg-black text-yellow-400 font-bold text-xl italic mr-3 shadow-md group-hover:scale-105 transition">
                 Ai
               </div>
               <div className="flex flex-col">
                  <span className="text-white font-bold text-lg leading-none hidden md:block">Prompt Editing</span>
                  <span className="text-white/70 text-xs hidden md:block">AI Resource Library</span>
               </div>
             </div>
          </div>
          <div className="flex items-center space-x-3">
             <button 
              onClick={() => setCurrentView(ViewState.GEMINI_TOOL)}
              className="hidden md:flex bg-yellow-400 text-black px-5 py-2 rounded-full text-sm font-bold hover:bg-yellow-300 transition items-center gap-2 shadow-lg transform hover:-translate-y-0.5"
             >
               <Wand2 size={16}/> <span>Generate Prompt</span>
             </button>
             <button className="text-white p-2 hover:bg-white/20 rounded-full transition"><Search size={22}/></button>
          </div>
        </div>
      </header>

      {/* Categories Nav */}
      <div className="bg-white shadow-sm sticky top-16 z-30 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-3 overflow-x-auto hide-scrollbar">
           <div className="flex space-x-3 min-w-max">
             {CATEGORIES.map((cat) => (
               <button 
                key={cat.id} 
                onClick={() => handleCategoryClick(cat.id)}
                className={`flex items-center space-x-2 px-5 py-2.5 rounded-full border transition-all font-medium whitespace-nowrap
                  ${selectedCategory === cat.id 
                    ? 'bg-red-50 border-red-200 text-red-600 shadow-inner' 
                    : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50 hover:border-gray-300 hover:shadow-sm'
                  }`}
               >
                 <div className={`p-1 rounded-full ${selectedCategory === cat.id ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-500'}`}>
                   {cat.icon}
                 </div>
                 <span>{cat.label}</span>
               </button>
             ))}
           </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-grow">
        {renderContent()}
      </div>

      {/* Footer */}
      <footer className="bg-[#111] text-gray-400 pt-16 pb-8 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          {/* Section 1: About */}
          <div>
             <div className="flex items-center mb-6">
               <div className="w-10 h-10 rounded-full border-2 border-yellow-400 flex items-center justify-center bg-transparent text-yellow-400 font-bold text-xl italic mr-2">
                 Ai
               </div>
               <span className="text-white font-bold text-xl">Prompt Editing</span>
             </div>
             <p className="text-sm leading-relaxed mb-6">
               Your #1 destination for trending AI photo editing prompts, tutorials, and resources. Powered by Google Gemini & Bing Image Creator.
             </p>
             <div className="flex space-x-4">
               <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#1877F2] hover:text-white transition"><Facebook size={18}/></a>
               <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#1DA1F2] hover:text-white transition"><Twitter size={18}/></a>
               <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#E1306C] hover:text-white transition"><Instagram size={18}/></a>
             </div>
          </div>

          {/* Section 2: Quick Links */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6 border-l-4 border-red-600 pl-3">Quick Links</h3>
            <ul className="space-y-3 text-sm">
              <li><button onClick={() => { setCurrentView(ViewState.HOME); setSelectedCategory('Trending'); }} className="hover:text-red-500 transition flex items-center"><ArrowRight size={14} className="mr-2"/> Home</button></li>
              <li><button onClick={() => setCurrentView(ViewState.GEMINI_TOOL)} className="hover:text-red-500 transition flex items-center"><ArrowRight size={14} className="mr-2"/> Generate Prompts</button></li>
              <li><button onClick={() => handleCategoryClick('Photo Editing')} className="hover:text-red-500 transition flex items-center"><ArrowRight size={14} className="mr-2"/> Photo Editing</button></li>
              <li><button onClick={() => handleCategoryClick('Gemini Prompts')} className="hover:text-red-500 transition flex items-center"><ArrowRight size={14} className="mr-2"/> Gemini Prompts</button></li>
            </ul>
          </div>

          {/* Section 3: Legal */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6 border-l-4 border-red-600 pl-3">Legal Info</h3>
             <ul className="space-y-3 text-sm">
              <li><button onClick={() => setCurrentView(ViewState.LEGAL_PRIVACY)} className="hover:text-red-500 transition flex items-center"><ArrowRight size={14} className="mr-2"/> Privacy Policy</button></li>
              <li><button onClick={() => setCurrentView(ViewState.LEGAL_TERMS)} className="hover:text-red-500 transition flex items-center"><ArrowRight size={14} className="mr-2"/> Terms & Conditions</button></li>
              <li><button onClick={() => setCurrentView(ViewState.LEGAL_DISCLAIMER)} className="hover:text-red-500 transition flex items-center"><ArrowRight size={14} className="mr-2"/> Disclaimer</button></li>
            </ul>
          </div>

          {/* Section 4: Support */}
          <div>
             <h3 className="text-white font-bold text-lg mb-6 border-l-4 border-red-600 pl-3">Need Help?</h3>
             <p className="text-sm text-gray-400 mb-4">Have questions? We are here to help you 24/7.</p>
             <button 
              onClick={() => setCurrentView(ViewState.CONTACT)}
              className="bg-gradient-to-r from-red-600 to-red-700 text-white px-6 py-2.5 rounded-lg text-sm font-semibold hover:from-red-700 hover:to-red-800 transition w-full md:w-auto shadow-md"
             >
               Contact Support
             </button>
             <div className="mt-8 text-xs text-gray-600 border-t border-gray-800 pt-4">
               © 2025 Ai Prompt Editing. All Rights Reserved.
             </div>
          </div>
        </div>
      </footer>
      
      {/* Scroll to top button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button 
          onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
          className="bg-red-600 text-white p-3 rounded-full shadow-xl hover:bg-red-700 transition transform hover:scale-110"
          aria-label="Scroll to top"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg>
        </button>
      </div>

    </div>
  );
};

export default App;