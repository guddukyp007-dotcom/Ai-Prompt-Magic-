import { Article, Category, Tag } from './types';

export const CATEGORIES: Category[] = [
  { id: '1', name: 'Girls Prompt', image: 'https://picsum.photos/seed/girls/200/200', color: 'bg-pink-100' },
  { id: '2', name: 'Boys Prompt', image: 'https://picsum.photos/seed/boys/200/200', color: 'bg-blue-100' },
  { id: '3', name: 'Couples Prompt', image: 'https://picsum.photos/seed/couples/200/200', color: 'bg-red-100' },
  { id: '4', name: 'Republic Day Ai', image: 'https://picsum.photos/seed/india/200/200', color: 'bg-orange-100' },
  { id: '5', name: 'Name Art', image: 'https://picsum.photos/seed/art/200/200', color: 'bg-purple-100' },
  { id: '6', name: 'Gemini Prompts', image: 'https://picsum.photos/seed/gemini/200/200', color: 'bg-indigo-100' },
];

export const ARTICLES: Article[] = [
  {
    id: '1',
    title: "The Viral Couples Trend That's Taking Over Social Media: Google Gemini AI Prompt Editing",
    image: 'https://picsum.photos/seed/couple1/600/400',
    category: 'Couples Prompt',
    author: 'Community guidelines',
    authorAvatar: 'https://picsum.photos/seed/admin/50/50',
    date: '2 hours ago',
    tags: ['AI', 'Couples Prompt', 'Photo Editing', 'Viral']
  },
  {
    id: '2',
    title: "Vote for BJP Ai Photo Editing with Gemini AI Stunning photos editing prompt",
    image: 'https://picsum.photos/seed/vote/600/400',
    category: 'Trending',
    author: 'Community guidelines',
    authorAvatar: 'https://picsum.photos/seed/admin/50/50',
    date: '5 hours ago',
    tags: ['Photo Editing', 'Trending', 'AI', 'Image editing']
  },
  {
    id: '3',
    title: "Top 5 Boys Stylish Google Gemini AI Photo Editing Prompts: Transform Your Photos Like a Pro",
    image: 'https://picsum.photos/seed/style/600/400',
    category: 'Boys Prompt',
    author: 'Community guidelines',
    authorAvatar: 'https://picsum.photos/seed/admin/50/50',
    date: '1 day ago',
    tags: ['Boys Prompt', 'Photo Editing Software', 'Online Editing Tools', 'Prompt Engineering Guide']
  },
  {
    id: '4',
    title: "How to Create Stunning Birthday Photo Edits with Google Gemini in 2025",
    image: 'https://picsum.photos/seed/bday/600/400',
    category: 'Tutorials',
    author: 'Community guidelines',
    authorAvatar: 'https://picsum.photos/seed/admin/50/50',
    date: '2 days ago',
    tags: ['AI photo editing tutorials', 'Photo Editing', 'Cloud storage solutions']
  },
  {
    id: '5',
    title: "Viral Cinematic Style Couples AI Photo Editing: Transform Your Love Story into Movie Magic",
    image: 'https://picsum.photos/seed/cinema/600/400',
    category: 'Couples Prompt',
    author: 'Community guidelines',
    authorAvatar: 'https://picsum.photos/seed/admin/50/50',
    date: '3 days ago',
    tags: ['Couples Prompt', 'Prompt engineering courses', 'AI', 'Image editing']
  }
];

export const POPULAR_TAGS: Tag[] = [
  { label: 'Discover more', url: '#' },
  { label: 'Photo Editing Software', url: '#' },
  { label: 'Photo Editing', url: '#' },
  { label: 'Prompt Engineering Guide', url: '#' },
  { label: 'Image editing', url: '#' },
  { label: 'Cloud storage solutions', url: '#' },
  { label: 'Online Editing Tools', url: '#' },
  { label: 'Prompt engineering courses', url: '#' },
  { label: 'AI', url: '#' },
  { label: 'AI photo editing tutorials', url: '#' },
];