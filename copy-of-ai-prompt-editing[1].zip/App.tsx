import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import CategoryRail from './components/CategoryRail';
import ArticleCard from './components/ArticleCard';
import PromptGenerator from './components/PromptGenerator';
import ArticleDetail from './components/ArticleDetail';
import Footer from './components/Footer';
import AboutUs from './components/pages/AboutUs';
import ContactUs from './components/pages/ContactUs';
import PrivacyPolicy from './components/pages/PrivacyPolicy';
import { CATEGORIES, ARTICLES, POPULAR_TAGS } from './constants';
import { Article } from './types';
import { Zap, ArrowUp, MessageCircle, FilterX, ExternalLink } from 'lucide-react';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<string>('home'); // 'home', 'about', 'contact', 'privacy'

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleArticleClick = (article: Article) => {
    setSelectedArticle(article);
    window.scrollTo(0, 0);
  };

  const handleBackToHome = () => {
    setSelectedArticle(null);
    window.scrollTo(0, 0);
  };

  const handleNavigation = (page: string) => {
    setCurrentPage(page);
    setSelectedArticle(null);
    setIsSidebarOpen(false);
    window.scrollTo(0, 0);
  };

  const handleCategorySelect = (category: string | null) => {
    setSelectedCategory(category);
    setSelectedTag(null); // Clear tag when category changes to avoid empty states
  };

  const handleTagSelect = (tagLabel: string) => {
    if (tagLabel === 'Discover more') {
        // Reset all filters
        setSelectedCategory(null);
        setSelectedTag(null);
    } else {
        setSelectedTag(tagLabel === selectedTag ? null : tagLabel);
    }
  };

  const handleJoinChannel = () => {
    // In a real app, this would be a real URL
    window.open('https://telegram.org/', '_blank');
  };

  // Filter articles based on selection
  const filteredArticles = ARTICLES.filter(article => {
    const matchesCategory = selectedCategory ? article.category === selectedCategory : true;
    const matchesTag = selectedTag ? article.tags?.includes(selectedTag) : true;
    return matchesCategory && matchesTag;
  });

  // 1. Check if Article Detail View
  if (selectedArticle) {
    return (
      <ArticleDetail 
        article={selectedArticle} 
        onBack={handleBackToHome} 
      />
    );
  }

  // 2. Check if Static Pages
  const renderContent = () => {
    switch (currentPage) {
      case 'about':
        return <AboutUs />;
      case 'contact':
        return <ContactUs />;
      case 'privacy':
        return <PrivacyPolicy />;
      case 'home':
      default:
        return (
          <>
             {/* Category Rail */}
            <CategoryRail 
                categories={CATEGORIES} 
                selectedCategory={selectedCategory}
                onSelect={handleCategorySelect}
            />

            {/* Join Channel CTA */}
            <div className="px-4 py-6 text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
              <h2 className="text-sm font-semibold text-gray-600 mb-3">हमारे सभी Trending Updates के लिए जुड़ें!</h2>
              <button 
                onClick={handleJoinChannel}
                className="bg-green-500 hover:bg-green-600 active:bg-green-700 text-white px-8 py-3 rounded-full font-bold shadow-lg shadow-green-200 transform transition-all hover:scale-105 hover:-translate-y-1 flex items-center gap-2 mx-auto"
              >
                <MessageCircle size={20} />
                चैनल जॉइन करें
                <ExternalLink size={16} className="opacity-70" />
              </button>
            </div>

            {/* Tag Cloud / Filters */}
            <div className="px-4 mb-6">
              <div className="flex flex-wrap justify-center gap-2">
                {POPULAR_TAGS.map((tag, index) => {
                   const isSelected = selectedTag === tag.label;
                   const isAction = tag.label === 'Discover more';
                   
                   return (
                    <button 
                        key={index}
                        onClick={() => handleTagSelect(tag.label)}
                        className={`
                        flex items-center gap-1 px-4 py-1.5 rounded-full border text-xs font-medium transition-all duration-200
                        ${isSelected 
                            ? 'bg-blue-600 text-white border-blue-600 shadow-md scale-105' 
                            : isAction 
                                ? 'bg-gray-900 text-white border-gray-900 hover:bg-gray-800' 
                                : 'bg-white text-gray-600 border-gray-200 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600'}
                        `}
                    >
                        {(!isAction && !isSelected) && <Zap size={10} className="fill-current opacity-50" />}
                        {tag.label}
                        {isSelected && <FilterX size={10} className="ml-1" />}
                    </button>
                   );
                })}
              </div>
            </div>

            {/* Prompt Generator Feature */}
            <PromptGenerator />

            {/* Section Title */}
            <div className="px-4 mb-4 flex items-center justify-between mx-4 border-l-4 border-red-600 pl-3 py-1">
                <div className="flex flex-col">
                    <h2 className="text-lg font-extrabold text-gray-900 uppercase tracking-tight leading-none">
                        {selectedCategory || (selectedTag ? selectedTag : 'Latest Posts')}
                    </h2>
                    {(selectedCategory || selectedTag) && (
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                            Filtered Results
                        </span>
                    )}
                </div>
                
                {(selectedCategory || selectedTag) && (
                    <button 
                        onClick={() => {
                            setSelectedCategory(null);
                            setSelectedTag(null);
                        }}
                        className="text-xs text-red-600 flex items-center gap-1 font-bold hover:bg-red-50 px-2 py-1 rounded transition-colors"
                    >
                        <FilterX size={14} /> Clear
                    </button>
                )}
            </div>

            {/* Articles Grid */}
            {filteredArticles.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 px-4 mb-8">
                {filteredArticles.map((article) => (
                    <ArticleCard 
                    key={article.id} 
                    article={article} 
                    onClick={handleArticleClick}
                    />
                ))}
                </div>
            ) : (
                <div className="px-4 py-12 text-center">
                    <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100 flex flex-col items-center">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                             <FilterX size={32} className="text-gray-400" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 mb-2">No posts found</h3>
                        <p className="text-gray-500 font-medium text-sm mb-4 max-w-xs">
                            We couldn't find any posts matching "{selectedTag || selectedCategory}".
                        </p>
                        <button 
                            onClick={() => {
                                setSelectedCategory(null);
                                setSelectedTag(null);
                            }}
                            className="px-6 py-2 bg-blue-600 text-white rounded-lg font-bold text-sm hover:bg-blue-700 transition-colors shadow-md"
                        >
                            View all posts
                        </button>
                    </div>
                </div>
            )}

            {/* Load More Button */}
            {filteredArticles.length > 0 && (
                <div className="flex justify-center pb-8">
                <button className="group px-8 py-3 bg-white border-2 border-gray-100 text-gray-600 font-bold text-sm rounded-xl shadow-sm hover:border-blue-200 hover:text-blue-600 hover:shadow-md transition-all">
                    Load More Posts
                </button>
                </div>
            )}
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans flex flex-col">
      <Header onMenuClick={() => setIsSidebarOpen(true)} />
      
      <Sidebar 
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
        onNavigate={handleNavigation}
      />

      <main className="max-w-3xl mx-auto w-full flex-grow">
        {renderContent()}
      </main>

      <Footer onNavigate={handleNavigation} />

      {/* Floating Action Button - Scroll Top */}
      <button 
        onClick={scrollToTop}
        className={`fixed bottom-6 right-6 bg-red-600 text-white p-3 rounded-full shadow-xl z-40 transition-all duration-300 transform hover:scale-110 ${showScrollTop ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}
      >
        <ArrowUp size={24} />
      </button>
    </div>
  );
}

export default App;