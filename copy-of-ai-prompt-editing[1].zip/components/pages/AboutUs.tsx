import React from 'react';
import { CheckCircle, Users, Zap, Award } from 'lucide-react';

const AboutUs: React.FC = () => {
  return (
    <div className="bg-white animate-in fade-in duration-500">
      {/* Hero Section */}
      <div className="bg-gray-900 text-white py-16 px-4 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        <h1 className="text-4xl font-bold mb-4 relative z-10">About Ai Prompt Editing</h1>
        <p className="text-gray-300 max-w-2xl mx-auto relative z-10">
          Empowering creators with the best AI prompts and photo editing resources to turn imagination into reality.
        </p>
      </div>

      <div className="max-w-3xl mx-auto px-5 py-12">
        <div className="prose prose-lg text-gray-700">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Who We Are</h2>
          <p className="mb-6">
            Welcome to <strong>Ai Prompt Editing</strong>, your number one source for all things related to AI Photo Editing, Prompt Engineering, and Digital Art Trends. We're dedicated to giving you the very best of AI tutorials, with a focus on Google Gemini, Midjourney, and Bing Image Creator.
          </p>
          <p className="mb-8">
            Founded in 2024, Ai Prompt Editing has come a long way from its beginnings. When we first started out, our passion for "democratizing digital art" drove us to do tons of research so that Ai Prompt Editing can offer you the world's most advanced prompt libraries. We now serve customers all over the world and are thrilled that we're able to turn our passion into our own website.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-6">Why Choose Us?</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-12">
            <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
              <Zap className="text-blue-600 mb-3" size={32} />
              <h3 className="font-bold text-gray-900 mb-2">Trending Content</h3>
              <p className="text-sm text-gray-600">We update our prompt library daily with the latest viral trends from Instagram and TikTok.</p>
            </div>
            <div className="bg-green-50 p-6 rounded-xl border border-green-100">
              <CheckCircle className="text-green-600 mb-3" size={32} />
              <h3 className="font-bold text-gray-900 mb-2">Verified Prompts</h3>
              <p className="text-sm text-gray-600">Every prompt is tested by our team to ensure it delivers high-quality results before we post it.</p>
            </div>
            <div className="bg-purple-50 p-6 rounded-xl border border-purple-100">
              <Users className="text-purple-600 mb-3" size={32} />
              <h3 className="font-bold text-gray-900 mb-2">Community Driven</h3>
              <p className="text-sm text-gray-600">We listen to our community. Request a style, and we'll engineer the perfect prompt for you.</p>
            </div>
            <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
              <Award className="text-orange-600 mb-3" size={32} />
              <h3 className="font-bold text-gray-900 mb-2">Expert Tutorials</h3>
              <p className="text-sm text-gray-600">Detailed step-by-step guides to help beginners become pro AI artists in no time.</p>
            </div>
          </div>

          <p className="text-center italic text-gray-600 border-l-4 border-gray-900 pl-4 py-2 bg-gray-50 rounded-r-lg">
            "Our mission is to bridge the gap between human creativity and artificial intelligence, making professional photo editing accessible to everyone."
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;