import React from 'react';
import { Shield } from 'lucide-react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="bg-white animate-in fade-in duration-500">
       <div className="bg-gray-900 text-white py-12 px-4 text-center">
        <div className="flex justify-center mb-4">
            <Shield size={48} className="text-blue-400" />
        </div>
        <h1 className="text-3xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-gray-400">Last updated: February 26, 2025</p>
      </div>

      <div className="max-w-3xl mx-auto px-5 py-12">
        <div className="prose prose-sm sm:prose lg:prose-lg text-gray-700 mx-auto">
          <p>
            At <strong>Ai Prompt Editing</strong>, accessible from https://aipromptediting.in, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Ai Prompt Editing and how we use it.
          </p>

          <h3>Log Files</h3>
          <p>
            Ai Prompt Editing follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services' analytics. The information collected by log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks.
          </p>

          <h3>Cookies and Web Beacons</h3>
          <p>
            Like any other website, Ai Prompt Editing uses 'cookies'. These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors' browser type and/or other information.
          </p>

          <h3>Google DoubleClick DART Cookie</h3>
          <p>
            Google is one of a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to www.website.com and other sites on the internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL – <a href="https://policies.google.com/technologies/ads" className="text-blue-600 hover:underline">https://policies.google.com/technologies/ads</a>
          </p>

          <h3>Third Party Privacy Policies</h3>
          <p>
            Ai Prompt Editing's Privacy Policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt-out of certain options.
          </p>

          <h3>Consent</h3>
          <p>
            By using our website, you hereby consent to our Privacy Policy and agree to its Terms and Conditions.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;