export interface Category {
  id: string;
  name: string;
  image: string;
  color?: string;
}

export interface Article {
  id: string;
  title: string;
  image: string;
  category: string;
  author: string;
  authorAvatar: string;
  date: string;
  tags?: string[]; // Added tags for filtering
}

export interface Tag {
  label: string;
  url: string;
}